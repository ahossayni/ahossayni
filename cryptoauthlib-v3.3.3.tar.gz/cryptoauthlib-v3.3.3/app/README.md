Application Support
========================

This directory is for application specific implementation of various use cases.

Methods in this directory provide a simple API to perform potentially complex 
combinations of calls to the main library or API.

@subpage app_info_ip_prot

@subpage app_info_pkcs11

@subpage app_info_secure_boot
